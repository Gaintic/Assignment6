/*
-- Query: SELECT * FROM pets_store.pets
LIMIT 0, 1000

-- Date: 2015-12-13 15:24
*/
INSERT INTO `pets` (`id`,`name`,`eat`,`drink`,`live`,`hobby`,`prize`,`image_path`) VALUES (1,'喜乐蒂牧羊犬','骨头','水','阳光充分,空气新鲜,能撒欢的地方啦~','和主人玩耍(づ￣ 3￣)づ',3000,'dog.jpg');
INSERT INTO `pets` (`id`,`name`,`eat`,`drink`,`live`,`hobby`,`prize`,`image_path`) VALUES (2,'布偶猫','小鱼干~','牛奶','有人类居住的地方，就有喵星人的存在！','和主人抱抱(づ￣ 3￣)づ',10000,'cat.jpg');
INSERT INTO `pets` (`id`,`name`,`eat`,`drink`,`live`,`hobby`,`prize`,`image_path`) VALUES (3,'安哥洛卡象龟','鱼和虾','水','半水生，避免龟的环境温度过高过低或大幅度波动','晒太阳(づ￣ 3￣)づ',150000,'turtle.jpg');
INSERT INTO `pets` (`id`,`name`,`eat`,`drink`,`live`,`hobby`,`prize`,`image_path`) VALUES (4,'白凤头鹦鹉','坚果，种子','水','提供的环境越接近原产地的环境越棒啦~','灰来灰去，叽叽喳喳(づ￣ 3￣)づ',6000,'parrot.jpg');
INSERT INTO `pets` (`id`,`name`,`eat`,`drink`,`live`,`hobby`,`prize`,`image_path`) VALUES (5,'布丁仓鼠','葵花籽（由动漫可知）','水','避免阳光直射或直接被大风吹，避免辐射和嘈杂。','就是吃吃吃啦(づ￣ 3￣)づ',25,'hamster.jpg');
INSERT INTO `pets` (`id`,`name`,`eat`,`drink`,`live`,`hobby`,`prize`,`image_path`) VALUES (6,'金花松鼠','松子','水','树洞和地下，宠物松鼠喜欢温暖干燥的地方~','玩玩玩~(づ￣ 3￣)づ',100,'squirrel.jpg');
INSERT INTO `pets` (`id`,`name`,`eat`,`drink`,`live`,`hobby`,`prize`,`image_path`) VALUES (7,'侏儒海棠兔','胡萝卜','水','草地和地下，养做宠物需要一个相对安静的环境~','还是吃吃吃呐(づ￣ 3￣)づ',300,'rabbit.jpg');
INSERT INTO `pets` (`id`,`name`,`eat`,`drink`,`live`,`hobby`,`prize`,`image_path`) VALUES (8,'暴风雪赤链蛇','幼鼠（活的较好）','水','温暖湿润，有可以躲避的洞的地方','晒太阳(づ￣ 3￣)づ',500,'snake.jpg');
INSERT INTO `pets` (`id`,`name`,`eat`,`drink`,`live`,`hobby`,`prize`,`image_path`) VALUES (9,'红眼鹰蜥','虫子（即bug）','水','干净！干净！还是干净！','晒太阳(づ￣ 3￣)づ',650,'lizard.jpg');
INSERT INTO `pets` (`id`,`name`,`eat`,`drink`,`live`,`hobby`,`prize`,`image_path`) VALUES (10,'黑金狮王斗鱼','水生植物，线虫','水','温度适宜，含氧量适宜的干净的水中','游来游去(づ￣ 3￣)づ',350,'fish.jpg');
INSERT INTO `pets` (`id`,`name`,`eat`,`drink`,`live`,`hobby`,`prize`,`image_path`) VALUES (11,'鹩哥','蚯蚓','水','注意提供小鹩洗澡的地方，然后干净干燥就好啦~','飞飞飞(づ￣ 3￣)づ',500,'myna.jpg');
INSERT INTO `pets` (`id`,`name`,`eat`,`drink`,`live`,`hobby`,`prize`,`image_path`) VALUES (12,'金丝雀','小米','水','金丝雀喜欢清洁的环境哦','唱歌啦(づ￣ 3￣)づ',200,'canary.jpg');

package service;

import javax.swing.JDialog;
import GUI.Login;

//������
public class Main {
	public static void main(String[] args){
		//��¼����
		try {
			Login dialog = new Login();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	
	}
}

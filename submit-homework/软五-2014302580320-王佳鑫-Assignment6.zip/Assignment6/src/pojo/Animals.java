package pojo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dao.Conn;

//������
public class Animals {
	public int id;
	public String name;
	public String eat;
	public String drink;
	public String live;
	public String hobby;
	public float prize;
	public String imagePath;
	
	public Animals(int id){
			this.id=id;
			ResultSet rs=null;
			PreparedStatement ps=null;
			try {
				String sql = "select id,name,eat,drink,live,hobby,prize,image_path from pets where id="+id;
				ps=Conn.getConn().prepareStatement(sql);
	            rs=ps.executeQuery();
	            while(rs.next()){
	            	this.name = rs.getString("name");
	            	this.eat = rs.getString("eat");
	            	this.drink = rs.getString("drink");
	            	this.live = rs.getString("live");
	            	this.hobby = rs.getString("hobby");
	            	this.prize = rs.getFloat("prize");
	            	this.imagePath = rs.getString("image_path");
	            }
	            ps.close();
		        Conn.getConn().close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}
	
	public int getId(){
		return id;
	}
	public String getName(){
		return name;
	}
	public String getEat(){
		return eat;
	}
	public String getDrink(){
		return drink;
	}
	public String getLive(){
		return live;
	}
	public String getHobby(){
		return hobby;
	}
	public float getPrize(){
		return prize;
	}
	public String getImagePath(){
		return imagePath;
	}
	
}
















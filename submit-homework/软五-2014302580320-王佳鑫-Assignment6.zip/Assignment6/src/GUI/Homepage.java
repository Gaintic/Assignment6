package GUI;

import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import pojo.Animals;

//������ҳ
public class Homepage extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JLabel store,animals1,animals2,animals3,animals4,animals5,animal1,animal2,animal3,animal4,animal5,animal6,animal7,animal8,animal9,animal10,animal11,animal12;
	private JButton i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,shoppingCart;
	
	public Homepage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(500, 80, 450, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new FlowLayout());
		setContentPane(contentPane);
		
		store = new JLabel("           XX�����            ");
		store.setFont(new Font("����", Font.PLAIN, 25));
		contentPane.add(store);
		
		animals1 = new JLabel("�����嵥                                   ");
		animals1.setFont(new Font("��Բ", Font.BOLD, 18));
		contentPane.add(animals1);
		
		animals2 = new JLabel("������                                        ");
		animals2.setFont(new Font("��Բ", Font.BOLD, 15));
		contentPane.add(animals2);
		
		animal1 = new JLabel("��                                         ");
		animal1.setFont(new Font("����", Font.PLAIN,15 ));
		contentPane.add(animal1);
		i1 = new JButton("����");
		i1.setFont(new Font("����", Font.PLAIN, 12));
		i1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {
							Animals a = new Animals(1);
							DetailsPage frame = new DetailsPage(a);
							frame.setVisible(true);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
				dispose();
			}
		});
		contentPane.add(i1);
		
		animal2 = new JLabel("è                                         ");
		animal2.setFont(new Font("����", Font.PLAIN,15 ));
		contentPane.add(animal2);
		i2 = new JButton("����");
		i2.setFont(new Font("����", Font.PLAIN, 12));
		i2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {
							Animals a = new Animals(2);
							DetailsPage frame = new DetailsPage(a);
							frame.setVisible(true);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
				dispose();
			}
		});
		contentPane.add(i2);
		
		animal5 = new JLabel("����                                       ");
		animal5.setFont(new Font("����", Font.PLAIN,15 ));
		contentPane.add(animal5);
		i5 = new JButton("����");
		i5.setFont(new Font("����", Font.PLAIN, 12));
		i5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {
							Animals a = new Animals(5);
							DetailsPage frame = new DetailsPage(a);
							frame.setVisible(true);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
				dispose();
			}
		});
		contentPane.add(i5);
		
		animal6 = new JLabel("����                                       ");
		animal6.setFont(new Font("����", Font.PLAIN,15 ));
		contentPane.add(animal6);
		i6 = new JButton("����");
		i6.setFont(new Font("����", Font.PLAIN, 12));
		i6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {
							Animals a = new Animals(6);
							DetailsPage frame = new DetailsPage(a);
							frame.setVisible(true);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
				dispose();
			}
		});
		contentPane.add(i6);
		
		animal7 = new JLabel("����                                       ");
		animal7.setFont(new Font("����", Font.PLAIN,15 ));
		contentPane.add(animal7);
		i7 = new JButton("����");
		i7.setFont(new Font("����", Font.PLAIN, 12));
		i7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {
							Animals a = new Animals(7);
							DetailsPage frame = new DetailsPage(a);
							frame.setVisible(true);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
				dispose();
			}
		});
		contentPane.add(i7);
		
		animals3 = new JLabel("������                                        ");
		animals3.setFont(new Font("��Բ", Font.BOLD, 15));
		contentPane.add(animals3);
		
		animal3 = new JLabel("�ڹ�                                       ");
		animal3.setFont(new Font("����", Font.PLAIN,15 ));
		contentPane.add(animal3);
		i3 = new JButton("����");
		i3.setFont(new Font("����", Font.PLAIN, 12));
		i3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {
							Animals a = new Animals(3);
							DetailsPage frame = new DetailsPage(a);
							frame.setVisible(true);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
				dispose();
			}
		});
		contentPane.add(i3);
		
		animal8 = new JLabel("��                                         ");
		animal8.setFont(new Font("����", Font.PLAIN,15 ));
		contentPane.add(animal8);
		i8 = new JButton("����");
		i8.setFont(new Font("����", Font.PLAIN, 12));
		i8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {
							Animals a = new Animals(8);
							DetailsPage frame = new DetailsPage(a);
							frame.setVisible(true);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
				dispose();
			}
		});
		contentPane.add(i8);
		
		animal9 = new JLabel("����                                       ");
		animal9.setFont(new Font("����", Font.PLAIN,15 ));
		contentPane.add(animal9);
		i9 = new JButton("����");
		i9.setFont(new Font("����", Font.PLAIN, 12));
		i9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {
							Animals a = new Animals(9);
							DetailsPage frame = new DetailsPage(a);
							frame.setVisible(true);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
				dispose();
			}
		});
		contentPane.add(i9);
		
		animals4 = new JLabel("����                                          ");
		animals4.setFont(new Font("��Բ", Font.BOLD, 15));
		contentPane.add(animals4);

		animal4 = new JLabel("����                                       ");
		animal4.setFont(new Font("����", Font.PLAIN,15 ));
		contentPane.add(animal4);
		i4 = new JButton("����");
		i4.setFont(new Font("����", Font.PLAIN, 12));
		i4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {
							Animals a = new Animals(4);
							DetailsPage frame = new DetailsPage(a);
							frame.setVisible(true);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
				dispose();
			}
		});
		contentPane.add(i4);
		
		animal11 = new JLabel("�Ӹ�                                       ");
		animal11.setFont(new Font("����", Font.PLAIN,15 ));
		contentPane.add(animal11);
		i11 = new JButton("����");
		i11.setFont(new Font("����", Font.PLAIN, 12));
		i11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {
							Animals a = new Animals(11);
							DetailsPage frame = new DetailsPage(a);
							frame.setVisible(true);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
				dispose();
			}
		});
		contentPane.add(i11);
		
		animal12 = new JLabel("��˿ȸ                                     ");
		animal12.setFont(new Font("����", Font.PLAIN,15 ));
		contentPane.add(animal12);
		i12 = new JButton("����");
		i12.setFont(new Font("����", Font.PLAIN, 12));
		i12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {
							Animals a = new Animals(12);
							DetailsPage frame = new DetailsPage(a);
							frame.setVisible(true);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
				dispose();
			}
		});
		contentPane.add(i12);
		
		animals5 = new JLabel("����                                          ");
		animals5.setFont(new Font("��Բ", Font.BOLD, 15));
		contentPane.add(animals5);
		
		animal10 = new JLabel("��                                         ");
		animal10.setFont(new Font("����", Font.PLAIN,15 ));
		contentPane.add(animal10);
		i10 = new JButton("����");
		i10.setFont(new Font("����", Font.PLAIN, 12));
		i10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {
							Animals a = new Animals(10);
							DetailsPage frame = new DetailsPage(a);
							frame.setVisible(true);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
				dispose();
			}
		});
		contentPane.add(i10);
		
		shoppingCart = new JButton("���ﳵ");
		shoppingCart.setFont(new Font("����", Font.PLAIN, 15));
		shoppingCart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {
							
							ShoppingCartPage frame = new ShoppingCartPage();
							frame.setVisible(true);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
				dispose();
			}
		});
		contentPane.add(shoppingCart);
	}
}

package GUI;

import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import dao.Conn;
import pojo.Animals;

//��������ҳ�棨����ҳ���е�ͼƬ�õ��Ǿ��Ե�ַ������Ҫ��һ�²��ܿ�����
public class DetailsPage extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JLabel name,eat,drink,live,hobby,prize,image;
	private JButton buy,back;
	
	public static String us;
	public int sum;
	
	private static int n;
	public static Animals a = new Animals(n);
	
	public DetailsPage(Animals a){
		DetailsPage.a=a;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(480, 80, 500, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new FlowLayout());
		setContentPane(contentPane);
		
		String s1 = "������"+a.name+"                               ";
		name = new JLabel(s1);
		name.setFont(new Font("��Բ", Font.BOLD, 15));
		contentPane.add(name);
		
		String s2 = "ϲ����ʳ�"+a.eat+"                        ";
		eat = new JLabel(s2);
		eat.setFont(new Font("��Բ", Font.BOLD, 15));
		contentPane.add(eat);
		
		String s3 = "ϲ������Ʒ��"+a.drink+"                          ";
		drink = new JLabel(s3);
		drink.setFont(new Font("��Բ", Font.BOLD, 15));
		contentPane.add(drink);
		
		String s4 = "��������"+a.live;
		live = new JLabel(s4);
		live.setFont(new Font("��Բ", Font.BOLD, 15));
		contentPane.add(live);
		
		String s5 = "���ã�"+a.hobby+"             ";
		hobby = new JLabel(s5);
		hobby.setFont(new Font("��Բ", Font.BOLD, 15));
		contentPane.add(hobby);
		
		String s7 = "C:\\Users\\Anastasia Wang\\javaWorkspace\\Assignment6\\animalsImage\\"+a.imagePath;
		image = new JLabel("");
		image.setIcon(new ImageIcon(s7));
		contentPane.add(image);

		String s6 = "�۸񣺣�"+a.prize;
		prize = new JLabel(s6);
		prize.setFont(new Font("��Բ", Font.BOLD, 20));
		contentPane.add(prize);
		
		buy = new JButton("���빺�ﳵ");
		buy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ResultSet rs=null;
				PreparedStatement ps1 = null;
				PreparedStatement ps2 = null;
				String sql1="select user_name,animal_name,sum from shopping_cart where user_name="+"'"+us+"'";
				String sql2="update shopping_cart set animal_name="+"'"+a.name+"'"+" where user_name="+"'"+us+"'";
				try {
					ps1=Conn.getConn().prepareStatement(sql1);
					rs=ps1.executeQuery();
					 while(rs.next()){
						 if(rs.getString("sum").equals("0")){
							 ps2=Conn.getConn().prepareStatement(sql2);
							 ps2.executeUpdate();
							 ps2.close();
							 
							 String sql4 = "update shopping_cart set sum=1 where user_name="+"'"+us+"'";
							 PreparedStatement ps4 = Conn.getConn().prepareStatement(sql4);
							 ps4.executeUpdate();
							 ps4.close();
						 }else{
							 String sql3 = "update shopping_cart set animal_name="+"'"+rs.getString("animal_name")+","+a.name+"'"+" where user_name="+"'"+us+"'";
							 PreparedStatement ps3 = Conn.getConn().prepareStatement(sql3);
							 ps3.executeUpdate();
							 ps3.close();
							 
							 String sql5 = "update shopping_cart set sum="+"'"+rs.getString("sum")+","+1+"'"+" where user_name="+"'"+us+"'";
							 PreparedStatement ps5 = Conn.getConn().prepareStatement(sql5);
							 ps5.executeUpdate();
							 ps5.close();
						 }
						 ShoppingCartPage.animalsNames = rs.getString("animal_name");
						 ShoppingCartPage.sums = rs.getString("sum");
					 }
					 
				ps1.close();

				Conn.getConn().close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	           
				try {
					Ok2 dialog = new Ok2();
					dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
					dialog.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		contentPane.add(buy);
		
		back = new JButton("������ҳ");
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {
							Homepage frame = new Homepage();
							frame.setVisible(true);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
				dispose();
			}
		});
		contentPane.add(back);
		
		
		
		
		
		
		
		
		
	}
}

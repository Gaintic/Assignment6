package GUI;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import dao.Conn;

//��¼����
@SuppressWarnings("serial")
public class Login  extends JDialog{
	private final JPanel contentPanel = new JPanel();
	private JLabel name,password;
	private JTextField tname;
	private JPasswordField tpassword;
	
	public Login(){
		setBounds(550, 250, 320, 200);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setLayout(new FlowLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		
		JPanel buttonPane = new JPanel();
		buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
		getContentPane().add(buttonPane, BorderLayout.SOUTH);
		
		name = new JLabel("�û���:        ");
		tname = new JTextField(16);
		contentPanel.add(name);
		contentPanel.add(tname);
		
		password = new JLabel("����:            ");
		tpassword = new JPasswordField(16);
		contentPanel.add(password);
		contentPanel.add(tpassword);
		
		JButton loginButton = new JButton("��¼");
		loginButton.setActionCommand("��¼");
		contentPanel.add(loginButton);
		loginButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0){
				String n = tname.getText();
				String p = new String(tpassword.getPassword());
				ResultSet rs=null;
				PreparedStatement ps=null;
				try {
					String sql = "select u_name,Password from new_table where u_name="+"'"+n+"'";
					ps=Conn.getConn().prepareStatement(sql);
		            rs=ps.executeQuery();
		          while(rs.next()){
			        if(p.equals(rs.getString("Password"))){
			        	DetailsPage.us = n;
			        	EventQueue.invokeLater(new Runnable() {
			    			public void run() {
			    				try {
			    					Homepage frame = new Homepage();
			    					frame.setVisible(true);
			    				} catch (Exception e) {
			    					e.printStackTrace();
			    				}
			    			}
			    		});  
			        	dispose();
			        }else{System.out.println("����������������룡");}
		        	  
		          }
		            ps.close();
			        Conn.getConn().close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		
		JButton okButton = new JButton("ע��");
		okButton.setActionCommand("ע��");
		buttonPane.add(okButton);
		getRootPane().setDefaultButton(okButton);
		okButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					dispose();
					Register dialog = new Register();
					dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
					dialog.setVisible(true);
				
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
		JButton cancelButton = new JButton("ȡ��");
		cancelButton.setActionCommand("ȡ��");
		buttonPane.add(cancelButton);
		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tname.setText("");
				tpassword.setText("");
			}
		});
	}
}

package GUI;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import dao.Conn;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

//ע��ҳ��
public class Register extends JDialog{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel = new JPanel();
	private JLabel name,password,repassword;
	private JTextField tname;
	private JPasswordField tpassword,trepassword;
	
	public Register(){
		setBounds(550, 250, 320, 200);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setLayout(new FlowLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		
		JPanel buttonPane = new JPanel();
		buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
		getContentPane().add(buttonPane, BorderLayout.SOUTH);
		
		name = new JLabel("�û���:      ");
		tname = new JTextField(16);
		contentPanel.add(name);
		contentPanel.add(tname);
		
		password = new JLabel("����:          ");
		tpassword = new JPasswordField(16);
		contentPanel.add(password);
		contentPanel.add(tpassword);
		
		repassword = new JLabel("ȷ������: ");
		trepassword = new JPasswordField(16);
		contentPanel.add(repassword);
		contentPanel.add(trepassword);
		
		JButton okButton = new JButton("ȷ��");
		okButton.setActionCommand("OK");
		buttonPane.add(okButton);
		getRootPane().setDefaultButton(okButton);
		okButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String n = tname.getText();
				String p1=new String(tpassword.getPassword());
				String p2=new String(trepassword.getPassword());
				PreparedStatement pstmt1 = null;
				PreparedStatement pstmt2 = null;
				if(n.length()<=16&&n.length()>0){
					if(0<p1.length()&&0<p2.length()&&p1.length()<=16&&p2.length()<=16){
						if(p2.equals(p1)){
							try {
								DetailsPage.us = n;
								String sql2 = "insert into shopping_cart (user_name,animal_name,sum) values(?,'',0)";
								pstmt2 = (PreparedStatement)Conn.getConn().prepareStatement(sql2);
								pstmt2.setString(1,n);
								pstmt2.executeUpdate();
							    pstmt2.close();
								
								String sql1 = "insert into new_table (u_name,Password) values(?,?)";
								pstmt1 = (PreparedStatement)Conn.getConn().prepareStatement(sql1);
								pstmt1.setString(1,n);
						        pstmt1.setString(2,p2);
						        pstmt1.executeUpdate();
						        pstmt1.close();
						        Conn.getConn().close();
						        EventQueue.invokeLater(new Runnable() {
					    			public void run() {
					    				try {
					    					Homepage frame = new Homepage();
					    					frame.setVisible(true);
					    				} catch (Exception e) {
					    					e.printStackTrace();
					    				}
					    			}
					    		});  
						        dispose();
							} catch (SQLException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}else {
							System.out.println("���벻һ�£���ȷ�Ϻ��������룡");
						}
					}else{if(p1.length()==0||p2.length()==0){
							System.out.println("���������룡");
						}else{
							System.out.println("���볤�ȹ��������������룡");
							}
					}
				}else{
					if(n.length()==0){
						System.out.println("�������û���!");
						}else{System.out.println("�û������ȹ��������������룡");}
				}
			}
		});
		JButton cancelButton = new JButton("ȡ��");
		cancelButton.setActionCommand("Cancel");
		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tname.setText("");
				tpassword.setText("");
				trepassword.setText("");
			}
		});
		buttonPane.add(cancelButton);
		
		
	}
}

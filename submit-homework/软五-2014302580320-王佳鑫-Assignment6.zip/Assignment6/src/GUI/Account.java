package GUI;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import dao.Conn;

//ȷ�ϸ������
public class Account extends JDialog{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel = new JPanel();
	private JLabel money;
	private JButton ok,cancle;

	public Account(){
		setBounds(550, 250, 320, 200);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setLayout(new FlowLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		
		String m = "                ���踶��"+ShoppingCartPage.p+"Ԫ���Ƿ�ȷ����           ";
		money = new JLabel(m);
		contentPanel.add(money);
		
		ok = new JButton("ȷ��");
		ok.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Ok dialog = new Ok();
					dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
					dialog.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
				dispose();
				
				String sql1="update shopping_cart set animal_name="+"''"+" where user_name="+"'"+DetailsPage.us+"'";
				String sql2="update shopping_cart set sum="+"''"+" where user_name="+"'"+DetailsPage.us+"'";
				try {
					PreparedStatement ps1 = Conn.getConn().prepareStatement(sql1);
					ps1.executeUpdate();
					PreparedStatement ps2 = Conn.getConn().prepareStatement(sql2);
					ps2.executeUpdate();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {
							
							ShoppingCartPage frame = new ShoppingCartPage();
							frame.setVisible(true);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
				
				
			}
		});
		contentPanel.add(ok);
		
		cancle = new JButton("ȡ��");
		cancle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		contentPanel.add(cancle);
		
	}

}

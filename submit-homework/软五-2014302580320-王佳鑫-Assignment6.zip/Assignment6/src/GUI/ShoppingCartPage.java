package GUI;

import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import dao.Conn;

//���ﳵҳ��
public class ShoppingCartPage extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JLabel heading;
	private JButton account,back;
	public static String animalsNames,sums;
	public static String[] animalName=null;
	public String[] sum;
	public static float p=0;
	
	public ShoppingCartPage(){
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(500, 80, 450, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new FlowLayout());
		setContentPane(contentPane);
		
		ResultSet rs=null;
		PreparedStatement ps = null;
		String sql="select user_name,animal_name,sum from shopping_cart where user_name="+"'"+DetailsPage.us+"'";
		try {
			ps=Conn.getConn().prepareStatement(sql);
			rs=ps.executeQuery();
			while(rs.next()){
			animalsNames = rs.getString("animal_name");
			sums = rs.getString("sum");
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		heading = new JLabel("                  �ҵĹ��ﳵ                  ");
		heading.setFont(new Font("����", Font.PLAIN, 25));
		contentPane.add(heading);
		

		animalName = animalsNames.split(",");
		sum = sums.split(",");
		for(int i=0;i<animalName.length;i++){
			JLabel l = new JLabel(animalName[i]+"                            ");
			l.setFont(new Font("��Բ", Font.PLAIN, 20));
			JLabel s = new JLabel(sum[i]);
			s.setFont(new Font("����", Font.PLAIN, 15));
			contentPane.add(l);
			contentPane.add(s);
			
			ResultSet rs1=null;
			PreparedStatement ps1 = null;
			String sql1="select prize from pets where name="+"'"+animalName[i]+"'";
			
			try {
				ps1=Conn.getConn().prepareStatement(sql1);
				rs1=ps1.executeQuery();
				while(rs1.next()){
				p=p+rs1.getFloat("prize");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		account = new JButton("����");
		account.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Account dialog = new Account();
					dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
					dialog.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
				dispose();
			}
		});
		contentPane.add(account);
		
		back = new JButton("������ҳ");
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {
							Homepage frame = new Homepage();
							frame.setVisible(true);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
				dispose();
			}
		});
		contentPane.add(back);
	}
}

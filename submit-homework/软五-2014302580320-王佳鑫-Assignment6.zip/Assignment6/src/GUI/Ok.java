package GUI;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

//����ɹ���ʾ��
public class Ok extends JDialog{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel = new JPanel();
	private JLabel l;

	public Ok(){
		setBounds(550, 300, 320, 100);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setLayout(new FlowLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		
		l=new JLabel("����ɹ���лл�ݹˣ�");
		l.setFont(new Font("��Բ", Font.PLAIN, 20));
		contentPanel.add(l);
	}
}
